<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Centro de criação')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <form name="charweapon" id="charweapon" method="post" action="" data-weapons-url="<?php echo e(route('load_weapons')); ?>">
        <div id="idDiv">
            <div class="col-span-3 sm:col-span-2">
                <label for="char_id" class="block text-sm font-medium text-gray-700">Personagens</label>
                <select id="char_id" name="char_id" autocomplete="char_id" value="" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    <option value="">Selecione</option>
                    <?php $__currentLoopData = $chars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $char): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($char->id); ?>"><?php echo e($char->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div id="idDiv2">
            <div class="col-span-3 sm:col-span-2">
                <label for="weapon_id" class="block text-sm font-medium text-gray-700">Personagens</label>
                <select id="weapon_id" name="weapon_id" autocomplete="weapon_id" value="" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    <option value="">Selecione</option>
                    <?php $__currentLoopData = $weapons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weapon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($weapon->id); ?>"><?php echo e($weapon->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Nome
                    </th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Raca e Classe
                    </th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Vida atual
                    </th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Acoes
                    </th>
                </tr>
            </thead>
            <tbody  class="bg-white divide-y divide-gray-200">
                
            </tbody>
        </table>

        <div id="charinfo">

        </div>
    </form>

    <script>
        $(document).ready(function() {
            $("#char_id").change(function() {
                const url = $('#charweapon').attr("data-weapons-url");
                charId = $(this).val();
                $.ajax({
                    url: url,
                    data: {
                        'char_id': charId,
                    },
                    success: function(data) {
                        $("#charinfo").html(data);
                        alert(charId);
                    }

                });

            });
        });
    </script>



 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\wamp64\www\copparpg\resources\views/weapon_info.blade.php ENDPATH**/ ?>